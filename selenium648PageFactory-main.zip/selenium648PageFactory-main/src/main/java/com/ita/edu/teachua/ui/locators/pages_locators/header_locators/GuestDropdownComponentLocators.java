package com.ita.edu.teachua.ui.locators.pages_locators.header_locators;

public class GuestDropdownComponentLocators  {
    public static final String REGISTER_BUTTON_XPATH = "//span/div[contains(text(),'Зареєструватися')]";
    public static final String LOGIN_BUTTON_XPATH = "//div[contains(text(),'Увійти')]";
}
