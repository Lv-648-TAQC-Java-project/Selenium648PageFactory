package com.ita.edu.teachua.ui.elements.custom_elements;

import com.ita.edu.teachua.ui.elements.base_element.BaseElement;
import org.openqa.selenium.WebElement;


public class DivElement extends BaseElement implements Div {


    public DivElement(WebElement element) {
        super(element);
    }
    public boolean isActive(){
        return getWrappedElement().isDisplayed();
    }

}
