package com.ita.edu.teachua.ui.pages.clubs_page;

import com.ita.edu.teachua.ui.pages.base_page.BasePage;
import org.openqa.selenium.WebDriver;

public class ShowOnMapPopUpComponent extends BasePage {
    public ShowOnMapPopUpComponent(WebDriver driver) {
        super(driver);
    }
}
