# selenium648

create in `src/test/resources` file  `data.properties`

```
baseURL=https://example.org.ua
adminEmail=example@test.com
adminPassword=example
```