package com.ita.edu.teachua.ui.elements.custom_elements;

import com.ita.edu.teachua.ui.elements.base_element.Element;
import com.ita.edu.teachua.ui.elements.base_element.ImplementedBy;

@ImplementedBy(DropdownElement.class)
public interface Dropdown extends Element {
    void click();
}
