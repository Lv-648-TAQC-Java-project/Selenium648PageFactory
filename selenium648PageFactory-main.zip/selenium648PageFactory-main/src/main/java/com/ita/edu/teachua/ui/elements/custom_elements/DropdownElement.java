package com.ita.edu.teachua.ui.elements.custom_elements;

import com.ita.edu.teachua.ui.elements.base_element.BaseElement;
import org.openqa.selenium.WebElement;

public class DropdownElement extends BaseElement implements Dropdown {

    public DropdownElement(WebElement element) {
        super(element);
    }
    public void click() {
        getWrappedElement().click();
    }
}
