package com.ita.edu.teachua.ui.locators_example;

import org.openqa.selenium.By;

public interface Locator {
    By getPath();
}
